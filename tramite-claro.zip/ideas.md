# Ideas de Diseño — Trámite Claro

<response>
<idea>
**Design Movement**: Corporate Clarity — Modernismo Institucional Español
**Core Principles**:
1. Claridad visual absoluta: cada sección comunica un único mensaje
2. Confianza transmitida mediante azul corporativo y verde de acción
3. Asimetría controlada: bloques de contenido con offset diagonal suave
4. Jerarquía tipográfica marcada entre títulos y cuerpo

**Color Philosophy**: Azul marino (#1a3a6b) como color de autoridad y confianza institucional. Verde (#3a8a3a) como color de acción y resolución. Blanco roto (#f8f9fa) como fondo para no cansar la vista. Contraste alto para accesibilidad.

**Layout Paradigm**: Secciones alternadas izquierda-derecha con bloques de color de fondo que crean ritmo visual. Hero con diagonal inferior. Cards de servicios en grid 2-3 columnas con iconos grandes.

**Signature Elements**:
1. Línea diagonal verde que separa el hero del resto del contenido
2. Cards con borde izquierdo de color (azul o verde) para jerarquía
3. Checkmarks verdes como elemento recurrente de validación

**Interaction Philosophy**: Hover suave en cards, transiciones de 200ms, chatbot flotante en esquina inferior derecha, WhatsApp en esquina inferior izquierda.

**Animation**: Fade-in al hacer scroll en secciones, slide-in lateral en cards de servicios, bounce suave en botones de CTA.

**Typography System**: Títulos en "Montserrat" Bold/ExtraBold, cuerpo en "Open Sans" Regular, subtítulos en "Montserrat" SemiBold. Tamaños: H1 3rem, H2 2rem, H3 1.4rem, body 1rem.
</idea>
<probability>0.08</probability>
</response>

<response>
<idea>
**Design Movement**: Minimal Trust — Diseño Suizo adaptado al sector servicios
**Core Principles**:
1. Grid rígido de 12 columnas con márgenes generosos
2. Tipografía como elemento visual principal
3. Color mínimo: solo azul y verde en acentos, todo lo demás en grises
4. Iconografía de línea fina y consistente

**Color Philosophy**: Blanco puro como base, azul #2563eb como único acento primario, verde #16a34a para CTAs secundarios. Grises neutros para texto secundario.

**Layout Paradigm**: Columna central estrecha para texto, elementos visuales que "rompen" el grid intencionalmente. Secciones con mucho espacio en blanco.

**Signature Elements**:
1. Números grandes en gris claro como decoración de fondo en secciones
2. Líneas horizontales finas como separadores
3. Tipografía en mayúsculas para etiquetas de sección

**Interaction Philosophy**: Microinteracciones mínimas, foco en la legibilidad. Chatbot discreto.

**Animation**: Transiciones de opacidad suaves, sin movimiento excesivo.

**Typography System**: "DM Sans" para todo, variando solo el peso. H1 4rem 800, H2 2.5rem 700, body 1.1rem 400.
</idea>
<probability>0.06</probability>
</response>

<response>
<idea>
**Design Movement**: Warm Professionalism — Diseño de servicios cercanos
**Core Principles**:
1. Calidez visual que transmite cercanía y accesibilidad
2. Azul corporativo combinado con tonos cálidos en secciones de fondo
3. Ilustraciones y carteles propios integrados como elementos visuales
4. Navegación clara con anclas a cada sección

**Color Philosophy**: Azul #1e3a8a como color principal de confianza, verde #15803d como color de éxito y acción, fondo en #f0f4ff (azul muy claro) para secciones alternadas, blanco para las demás.

**Layout Paradigm**: Landing page de una sola página con navegación sticky. Secciones en bloques completos con fondo alternado. Hero con imagen de fondo y overlay. Cards de servicios con sombra suave.

**Signature Elements**:
1. Gradiente diagonal azul-verde en el hero
2. Badges de "Sin permanencia" y "Precio antes de gestionar" como elementos de confianza
3. Timeline visual para el proceso de trabajo

**Interaction Philosophy**: Scroll suave entre secciones, chatbot con burbujas de conversación, formulario con validación en tiempo real.

**Animation**: Entrada de elementos desde abajo al hacer scroll, contador animado de estadísticas, chatbot con animación de "escribiendo".

**Typography System**: "Nunito" para títulos (redondeado y amigable), "Source Sans 3" para cuerpo. H1 3.5rem 800, H2 2.2rem 700.
</idea>
<probability>0.09</probability>
</response>

## Diseño Elegido: Warm Professionalism

Se elige el enfoque de **Warm Professionalism** por ser el más adecuado para un servicio de asistencia administrativa dirigido al público general. Transmite confianza institucional (azul) combinada con accesibilidad y cercanía (verde, tipografía redondeada). La estructura de landing page de una sola página facilita la navegación y la conversión.
